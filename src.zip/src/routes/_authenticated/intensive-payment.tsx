import { createFileRoute } from "@tanstack/react-router";
import { LoanPaymentPage } from "./loan-payment";

export const Route = createFileRoute("/_authenticated/intensive-payment")({ component: LoanPaymentPage });
